package org.inria.restlet.mta.internals;

public class Tweet {

}
