package org.inria.restlet.mta.resources;

import org.restlet.resource.ServerResource;

public class TweetsResource extends ServerResource {

	/*
	 * Ajouter une classe TweetsResource vers laquelle les requêtes pour l'URI /users/{userId}/tweets seront dirigées 
	 */
	
	
}
